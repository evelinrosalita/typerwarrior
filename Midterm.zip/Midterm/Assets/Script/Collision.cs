﻿using UnityEngine;
using System.Collections;

public class Collision : MonoBehaviour {

	void OnTriggerEnter(Collider other) {
		if (other.gameObject.name == "Character")
		{
			Destroy(gameObject);
		}
		
	}
}
