﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
public class FinishButton : MonoBehaviour {

	Button nextButton;
	void Start () {
		nextButton = GetComponent<Button>();
		nextButton.GetComponent<Button>().enabled = false;
		nextButton.GetComponentInChildren<CanvasRenderer>().SetAlpha(0);
		nextButton.GetComponentInChildren<Text>().color = Color.clear;
	}
}
