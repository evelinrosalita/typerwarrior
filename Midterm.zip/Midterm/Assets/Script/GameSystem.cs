﻿using UnityEngine;
using System.Collections;

public class GameSystem : MonoBehaviour {
	public string randomResult ="";
	public bool winnerGame = false;
	public bool isBox = false;
	public bool isPassed = false;

	void Start () {
		//Cursor.visible = false;
	}
	void Update () {

	}

	public void RandomString(){
		string[] myDataStrings = new string[] {"cat", "student", "dog","elephant","bangkok","thailand","monkey","teacher","doctor","world","car","boat"};
		string myRandomString  = myDataStrings[Random.Range(0, myDataStrings.Length)];

		randomResult = myRandomString.ToUpper ();
		//Debug.Log(randomResult);
			
	}

	public void IsWinner(){
		winnerGame = true;
		Debug.Log (winnerGame);
	}

	public void boxReset(){
		isBox = true;
	}

	public void CorrectAnswer(){
		isPassed = true;
	}


}
