﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class InputPlay : MonoBehaviour {
	public GameSystem system;
	public pass_message pass_msg;
	public bad_message bad_msg;


	void Start () {
		if(system ==null){
			GameObject _system = GameObject.FindGameObjectWithTag("GameSystem") as GameObject;
			system = _system.GetComponent<GameSystem>();
		}
		if(pass_msg ==null){
			GameObject _TypeCorrect = GameObject.FindGameObjectWithTag("TypeCorrect") as GameObject;
			pass_msg = _TypeCorrect.GetComponent<pass_message>();
		}
		if(bad_msg ==null){
			GameObject _TypeWrong = GameObject.FindGameObjectWithTag("TypeWrong") as GameObject;
			bad_msg = _TypeWrong.GetComponent<bad_message>();
		}

	}
	public void FixedUpdate(){
		var input = gameObject.GetComponent<InputField>();
		input.ActivateInputField();
		
		var se= new InputField.SubmitEvent();
		se.AddListener(SubmitName);
		input.onEndEdit = se;

		/*if (system.winnerGame == true) {
			input.GetComponent<InputField>().enabled = false;
			input.GetComponentInChildren<Image>().color = Color.clear;
			input.GetComponentInChildren<Text>().color = Color.clear;
		}*/

	}
	

	private void SubmitName(string arg0)
	{
		//Debug.Log(arg0);
		if (arg0.ToUpper() == system.randomResult) {
			pass_msg.GetComponent<Text>().enabled = true;
			bad_msg.GetComponent<Text>().enabled = false;
			system.CorrectAnswer();
			StartCoroutine(clearScreen());
		} else {
			bad_msg.GetComponent<Text>().enabled = true;
			pass_msg.GetComponent<Text>().enabled = false;
			StartCoroutine(clearScreen());
		}
	}

	public IEnumerator clearScreen(){

			yield return new WaitForSeconds(.4f);
			pass_msg.GetComponent<Text>().enabled = false;
			bad_msg.GetComponent<Text>().enabled = false;
			system.RandomString ();

	}
}
