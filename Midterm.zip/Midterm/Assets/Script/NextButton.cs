﻿using UnityEngine;
using System.Collections;

public class NextButton : MonoBehaviour {
	public void OnClickPlay(){
		Application.LoadLevel("Scene1");
	}
}
