﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Player : MonoBehaviour {
	Animator anim;
	public float speed = 4.0F;
	public float jumpSpeed = 7.0F;
	public float gravity = 10.0F;
	private Vector3 moveDirection = Vector3.zero;
	public bool Winner = false;
	public bool wordshow = false;

	public GameSystem system;

	void Start(){
		anim = GetComponent <Animator> ();
		Time.timeScale = 1;
		if(system ==null){
			GameObject _system = GameObject.FindGameObjectWithTag("GameSystem") as GameObject;
			system = _system.GetComponent<GameSystem>();
		}
	}


	void Update() {
		anim.SetBool ("IsJumping", false);
		
		CharacterController controller = GetComponent<CharacterController>();
		if (controller.isGrounded) {
				moveDirection = new Vector3(0, 0, 0);
				moveDirection = transform.TransformDirection(moveDirection);
				moveDirection *= speed;
		}

		if (Input.GetButton("Jump")){
			Character_jump();
		}

		if (system.isPassed == true) {
			Character_jump();
			system.boxReset();
			system.isPassed = false;
		}

		moveDirection.y -= gravity * Time.deltaTime;
		controller.Move(moveDirection * Time.deltaTime);
	}

	public void Character_jump(){
		moveDirection.y = jumpSpeed;
		moveDirection.z = speed;
		anim.SetBool ("IsJumping", true);

	}

	void OnTriggerEnter(Collider other) {


		switch (other.gameObject.name)
		{
		case "Reward":
			system.IsWinner();
			break;
		case "GameOver":
			print ("Game Over");
			break;
		default:
			break;
		}

	}

}