﻿using UnityEngine;
using System.Collections;
//New GUI
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class RandomText : MonoBehaviour {
	Text ShowText;
	string blankText = "";
	bool isBlinking = true;
	public GameSystem system;
	public bool isRandom = false;
	public string word_merge ="";

	void Start () {
		ShowText = GetComponent<Text>();

		if(system ==null){
			GameObject _system = GameObject.FindGameObjectWithTag("GameSystem") as GameObject;
			system = _system.GetComponent<GameSystem>();
		}
	}

	public void Random_String(){
		StartCoroutine(BlinkText());
		system.RandomString();

	}

	void Update(){
		if (isRandom == false) {
			Random_String ();
			isRandom = true;
		} 

		if (system.isBox == true) {
			isRandom = false;
		}

		if (system.winnerGame == true) {
			ShowText.text = "Stage Clear!";
			isBlinking = false;
			StartCoroutine(stopPlay());
		}
		word_merge = system.randomResult;

	}

	public IEnumerator BlinkText(){
		while(isBlinking){
			ShowText.text = blankText;
			yield return new WaitForSeconds(.5f);
			ShowText.text = word_merge;
			yield return new WaitForSeconds(.5f); 
		}
	}

	public IEnumerator stopPlay(){
		yield return new WaitForSeconds(5f);
		Time.timeScale = 0;
	}
}
