﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class TimeCouter : MonoBehaviour {
	Text counterText;
	float startTime = 11;
	public string countValue= "";
	public GameSystem system;

	void Start () {
		counterText = GetComponent<Text>();
		Time.timeScale = 1;
		if(system ==null){
			GameObject _system = GameObject.FindGameObjectWithTag("GameSystem") as GameObject;
			system = _system.GetComponent<GameSystem>();
		}
	}

	void Update () {
		startTime -= Time.deltaTime;
		int iValue = (int)startTime;
		iValue = Mathf.FloorToInt(startTime);
		if (iValue < 0) {
			iValue = 0;
		}
		countValue = iValue.ToString ();
		counterText.text = ""+countValue;

		if (system.isBox == true) {
			startTime = 11;
			system.isBox=false;
		}
	}
}
