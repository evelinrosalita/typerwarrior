﻿using UnityEngine;
using System.Collections;

public class Water : MonoBehaviour {
	float speed = 0.04f;
	float offset;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		offset = Time.time * speed;
		GetComponent<Renderer>().material.mainTextureOffset= new Vector2(0,-offset);
	}
}
