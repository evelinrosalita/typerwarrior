﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
public class bad_message : MonoBehaviour {
	Text badText;
	void Start () {
		badText = GetComponent<Text>();
		badText.GetComponent<Text>().enabled = false;
	}

}
