﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class pass_message : MonoBehaviour {
	Text passText;
	void Start () {
		passText = GetComponent<Text>();
		passText.GetComponent<Text>().enabled = false;
	}
}
