﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class winnerText : MonoBehaviour {
	Text winner_txt;
	public GameSystem system;
	void Start () {
		if(system ==null){
			GameObject _system = GameObject.FindGameObjectWithTag("GameSystem") as GameObject;
			system = _system.GetComponent<GameSystem>();
		}
		winner_txt = GetComponent<Text>();
		winner_txt.GetComponent<Text>().enabled = false;
	}

	void Update(){
		if (system.winnerGame == true) {
			winner_txt.GetComponent<Text>().enabled = true;
		}
	}
}
